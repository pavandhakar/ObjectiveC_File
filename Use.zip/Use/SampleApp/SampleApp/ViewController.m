//
//  ViewController.m
//  SampleApp
//
//  Created by ajay jha on 06/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "HomeViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)HomeView:(id)sender
{
    HomeViewController *go=[self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    
    [self.navigationController pushViewController:go animated:YES];
}
@end
