//
//  ViewController.h
//  SampleApp
//
//  Created by ajay jha on 06/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(IBAction)HomeView:(id)sender;
@end

