//
//  SecondViewController.m
//  SampleApp
//
//  Created by ajay jha on 06/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "SecondViewController.h"
#import "ViewController.h"
#import "HomeViewController.h"
#import "FirstViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)goToHome:(id)sender
{
    //HomeViewController *goHome=[self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    
   NSArray *viewArr =self.navigationController.viewControllers;
    for (int i=0; i<viewArr.count; i++)
    {
        id viewName=[viewArr objectAtIndex:i];
        
        if ([viewName isKindOfClass:[HomeViewController class]])
        {
            [self.navigationController popToViewController:viewName animated:YES];
            break;
        }
        
        
    }
    
    
}
-(IBAction)goToViewCon:(id)sender
{
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(IBAction)goTofirest:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
