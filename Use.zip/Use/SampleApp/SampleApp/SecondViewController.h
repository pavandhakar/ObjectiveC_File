//
//  SecondViewController.h
//  SampleApp
//
//  Created by ajay jha on 06/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

-(IBAction)goToHome:(id)sender;
-(IBAction)goTofirest:(id)sender;
-(IBAction)goToViewCon:(id)sender;

@end
