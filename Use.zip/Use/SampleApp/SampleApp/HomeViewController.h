//
//  HomeViewController.h
//  SampleApp
//
//  Created by ajay jha on 06/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController

-(IBAction)firstView:(id)sender;

@end
