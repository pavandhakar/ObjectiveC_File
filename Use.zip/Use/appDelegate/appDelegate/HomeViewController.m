//
//  HomeViewController.m
//  appDelegate
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "HomeViewController.h"
#import "AppDelegate.h"
#import "ViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray *appdelegateData=dataSharedByAppdelegat.delegateShare;
    NSDictionary *dictData=[appdelegateData objectAtIndex:0];
    
    NSString *name=[dictData objectForKey:@"name"];
    NSString *mobile=[dictData objectForKey:@"mobile"];
    NSString *email=[dictData objectForKey:@"email"];
    UIImage *imageShow=[dictData objectForKey:@"image"];
    
    self.showName.text=name;
    self.showmob.text=mobile;
    self.showemail.text=email;
    self.showImage.image=imageShow;

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
