//
//  ViewController.m
//  appDelegate
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "HomeViewController.h"
#import "AppDelegate.h"

@interface ViewController ()
{
    NSMutableArray *arrSave;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    arrSave =[[NSMutableArray alloc]init];

    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
    
    // Dispose of any resources that can be recreated.
}
-(IBAction)Save:(id)sender
{
    NSMutableDictionary *saveMuta=[[NSMutableDictionary alloc]init];
    
    [saveMuta setObject:_Nane.text forKey:@"name"];
    [saveMuta setObject:_Mobile.text forKey:@"mobile"];
    [saveMuta setObject:_Email.text forKey:@"email"];
    [saveMuta setObject:_Pass.text forKey:@"pass"];
    [saveMuta setValue:_userImg.image forKey:@"image"];
    
    [arrSave addObject:saveMuta];
    
    dataSharedByAppdelegat.delegateShare=arrSave;
}

-(IBAction)SaveImage:(id)sender
{
    UIImagePickerController *imagePicker=[[UIImagePickerController alloc]init];
   
    [imagePicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    imagePicker.delegate=self;
    
    [self presentViewController:imagePicker animated:YES completion:nil];
 
 }
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo 
{
    self.userImg.image=image;
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)Go:(id)sender
{
    HomeViewController *goHome=[self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    
    [self.navigationController pushViewController:goHome animated:YES];
}


@end
