//
//  HomeViewController.h
//  appDelegate
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController


@property(strong,nonatomic)IBOutlet UILabel *showName;
@property(strong,nonatomic)IBOutlet UILabel *showmob;
@property(strong,nonatomic)IBOutlet UILabel *showemail;

@property(strong,nonatomic)IBOutlet UIImageView *showImage;

@end
