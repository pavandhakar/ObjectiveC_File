//
//  ViewController.h
//  appDelegate
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(strong,nonatomic)IBOutlet UITextField *Nane;
@property(strong,nonatomic)IBOutlet UITextField *Mobile;
@property(strong,nonatomic)IBOutlet UITextField *Email;
@property(strong,nonatomic)IBOutlet UITextField *Pass;
@property(strong,nonatomic)IBOutlet UIImageView *userImg;


-(IBAction)Save:(id)sender;
-(IBAction)SaveImage:(id)sender;

-(IBAction)Go:(id)sender;


@end

