//
//  DetailViewController.h
//  TableViewNew
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property(strong,nonatomic)NSDictionary *infoDetail;

@property(strong,nonatomic)IBOutlet UILabel *txtDetailName;

@property(strong,nonatomic)IBOutlet UILabel *txtDetailMob;
@property(strong,nonatomic)IBOutlet UILabel *txtDetailEmail;

@property(strong,nonatomic)IBOutlet UIImageView *detailImage;

@end
