//
//  HomeViewController.h
//  TableViewNew
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(strong,nonatomic)NSArray *homeData;

@property(strong,nonatomic)IBOutlet UITableView *tableView1;

@end
