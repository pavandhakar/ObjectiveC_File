//
//  HomeViewController.m
//  TableViewNew
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "HomeViewController.h"
#import "CustomTableViewCell.h"
#import "ViewController.h"
#import "DetailViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView1.delegate=self;
    self.tableView1.dataSource=self;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.homeData.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier=@"callIdentifier";
    
    CustomTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:identifier];
   
    NSDictionary *dictData=[self.homeData objectAtIndex:indexPath.row];
    NSString *name=[dictData objectForKey:@"Name"];
    NSString *Mob=[dictData objectForKey:@"Mobile"];
    UIImage *image=[dictData objectForKey:@"setImage"];
    
    cell.txtName.text=name;
    cell.pic.image=image;
    cell.txtMob.text=Mob;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100.0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dataSendDetail=[self.homeData objectAtIndex:indexPath.row ];
    DetailViewController *GoDetail=[self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];

    GoDetail.infoDetail=dataSendDetail;
    [self.navigationController pushViewController:GoDetail animated:YES];
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
