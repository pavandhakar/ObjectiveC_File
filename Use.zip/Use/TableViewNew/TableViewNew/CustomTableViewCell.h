//
//  CustomTableViewCell.h
//  TableViewNew
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *txtName;
@property(strong,nonatomic)IBOutlet UILabel *txtMob;

@property(strong,nonatomic)IBOutlet UIImageView *pic;

@end
