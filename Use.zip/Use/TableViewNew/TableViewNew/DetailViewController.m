//
//  DetailViewController.m
//  TableViewNew
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *showName=[self.infoDetail objectForKey:@"Name"];
    NSString *showMob=[self.infoDetail objectForKey:@"Mobile"];
    NSString *showEmail=[self.infoDetail objectForKey:@"Email"];
    UIImage *showImg=[self.infoDetail objectForKey:@"setImage"];
   
    self.txtDetailName.text=showName;
    self.txtDetailMob.text=showMob;
    self.txtDetailEmail.text=showEmail;
    self.detailImage.image=showImg;

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
