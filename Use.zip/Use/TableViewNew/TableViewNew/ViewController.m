//
//  ViewController.m
//  TableViewNew
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "HomeViewController.h"

@interface ViewController ()
{
    NSMutableArray *arraySave;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arraySave=[[NSMutableArray alloc]init];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)saveRecord:(id)sender
{   NSMutableDictionary *saveToDicti=[[NSMutableDictionary alloc]init];
    
    [saveToDicti setObject:_txtName.text forKey:@"Name"];
    [saveToDicti setObject:_txtMob.text forKey:@"Mobile"];
    [saveToDicti setObject:_txtEmail.text forKey:@"Email"];
    
    [saveToDicti setObject:_imgImage.image forKey:@"setImage"];
    
    [arraySave addObject:saveToDicti];
}
-(IBAction)imageSave:(id)sender
{
    UIImagePickerController *imagePicker=[[UIImagePickerController alloc]init];
    imagePicker.delegate=self;
    [self presentViewController:imagePicker animated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo
{
    self.imgImage.image=image;
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(IBAction)goHome:(id)sender
{
    HomeViewController  *goHome=[self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    
    goHome.homeData=arraySave;
    
    [self.navigationController pushViewController:goHome animated:YES];
}




@end
