//
//  ViewController.h
//  TableViewNew
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(strong,nonatomic)IBOutlet UITextField *txtName;

@property(strong,nonatomic)IBOutlet UITextField *txtMob;
@property(strong,nonatomic)IBOutlet UITextField *txtEmail;

@property(strong,nonatomic)IBOutlet UIImageView *imgImage;

-(IBAction)imageSave:(id)sender;
-(IBAction)saveRecord:(id)sender;
-(IBAction)goHome:(id)sender;

@end

