//
//  DetailViewController.h
//  CollectionViweSample
//
//  Created by ajay jha on 31/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property(strong,nonatomic)NSArray *viewToDetail;


@property(strong,nonatomic)IBOutlet UILabel *lblName;
@property(strong,nonatomic)IBOutlet UILabel *lblAge;
@property(strong,nonatomic)IBOutlet UILabel *lblCategort;
@property(strong,nonatomic)IBOutlet UILabel *lblEmail;
@property(strong,nonatomic)IBOutlet UIImageView *Image;


@end
