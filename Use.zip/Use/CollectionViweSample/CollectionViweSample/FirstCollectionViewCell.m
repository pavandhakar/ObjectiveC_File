//
//  FirstCollectionViewCell.m
//  CollectionViweSample
//
//  Created by ajay jha on 31/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "FirstCollectionViewCell.h"

@implementation FirstCollectionViewCell

@end
