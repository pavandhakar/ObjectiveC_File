//
//  ViewController.m
//  CollectionViweSample
//
//  Created by ajay jha on 31/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "HomeViewController.h"

@interface ViewController ()
{
    NSMutableArray *arraySave;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arraySave=[[NSMutableArray alloc]init];

    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)saveRecord:(id)sender
{
    NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
    [dict setObject:_txtName.text forKey:@"name"];
    [dict setObject:_txtAge.text forKey:@"age"];
    [dict setObject:_txtEmail.text forKey:@"email"];
    [dict setObject:_txtCategort.text forKey:@"category"];
    [dict setObject:_imgImage.image forKey:@"image"];
    
    [arraySave addObject:dict];
    

}
-(IBAction)imageSave:(id)sender
{
    UIImagePickerController *picker=[[UIImagePickerController alloc]init];
    picker.delegate=self;
    [self presentViewController:picker animated:YES completion:nil];
    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo
{
    self.imgImage.image=image;
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(IBAction)goHome:(id)sender
{
    HomeViewController  *goHome=[self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    
    goHome.viewData=arraySave;
    
    [self.navigationController pushViewController:goHome animated:YES];

}
















@end
