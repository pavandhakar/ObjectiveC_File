//
//  DetailViewController.m
//  CollectionViweSample
//
//  Created by ajay jha on 31/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "DetailViewController.h"
#import "HomeViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSDictionary *dict=[self.viewToDetail objectAtIndex:0];
    NSString *name=[dict objectForKey:@"name"];
    NSString *email=[dict objectForKey:@"email"];
    NSString *age=[dict objectForKey:@"age"];
    NSString *category=[dict objectForKey:@"category"];
    UIImage *image=[dict objectForKey:@"image"];
    self.lblName.text=name;
    self.lblEmail.text=email;
    self.lblAge.text=age;
    self.lblCategort.text=category;
    self.Image.image=image;
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
