//
//  HomeViewController.h
//  CollectionViweSample
//
//  Created by ajay jha on 31/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate>

@property(strong,nonatomic)NSArray *viewData;

@property(strong,nonatomic)IBOutlet UICollectionView *collection;

@end
