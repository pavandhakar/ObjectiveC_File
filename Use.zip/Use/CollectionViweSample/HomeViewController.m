//
//  HomeViewController.m
//  CollectionViweSample
//
//  Created by ajay jha on 31/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "HomeViewController.h"
#import "ViewController.h"
#import "FirstCollectionViewCell.h"
#import "DetailViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.collection.dataSource=self;
    self.collection.delegate=self;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.viewData.count;
    
   }

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
static NSString *identifier=@"cellIdentifier";

    FirstCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    NSMutableDictionary *backMuta=[self.viewData objectAtIndex:0];
    NSString *name=[backMuta objectForKey:@"name"];
    NSString *age=[backMuta objectForKey:@"age"];
    UIImage *image=[backMuta objectForKey:@"image"];
    
    cell.lblName.text=name;
    cell.lblAge.text=age;
    cell.showImage.image=image;
    
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *data=[self.viewData objectAtIndex:0];
    
    DetailViewController *goDetail=[self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
   
    goDetail.viewToDetail=data;
    [self.navigationController pushViewController:goDetail animated:YES];
    
}








@end
