//
//  ViewController.h
//  SingletonClass
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property(strong,nonatomic)IBOutlet UITextField *name;
@property(strong,nonatomic)IBOutlet UITextField *mob;
@property(strong,nonatomic)IBOutlet UITextField *email;
@property(strong,nonatomic)IBOutlet UIImageView *imageSave;

-(IBAction)saveData:(id)sender;
-(IBAction)saveImage:(id)sender;

-(IBAction)goShowDetail:(id)sender;


@end

