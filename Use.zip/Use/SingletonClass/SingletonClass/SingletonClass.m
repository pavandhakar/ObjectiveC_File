//
//  SingletonClass.m
//  SingletonClass
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "SingletonClass.h"

@implementation SingletonClass

static SingletonClass *instance=nil;

+(SingletonClass*)custamSingleton
{
    if (instance==nil)
    {
        instance = [[SingletonClass alloc]init];

    }
    return instance;
}

@end
