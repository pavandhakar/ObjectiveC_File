//
//  ViewController.m
//  delegate
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "ServiceClass.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSURL *url1=[NSURL URLWithString:@"http;// abcdefghijklmnopqrstuvwxyz@gmail.com"];
    
    ServiceClass *cellObj=[[ServiceClass alloc]init];
    cellObj.delegate222=self;
    [cellObj hitToActionWebService:url1];


    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)success:(NSDictionary*)success1
{
    NSLog(@"success mission ");
}
-(void)failure:(NSDictionary*)failure2
{
    NSString *answear=[failure2 objectForKey:@"usernName"];
    NSLog(@"sorry %@ you are not connect to internet/erroe 404",answear);
}








@end
