//
//  ViewController.h
//  delegate
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController



//-(IBAction)saveImage:(id)sender;
//-(IBAction)saveData:(id)sender;
@end

