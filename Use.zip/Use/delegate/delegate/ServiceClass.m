//
//  ServiceClass.m
//  delegate
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ServiceClass.h"

@implementation ServiceClass
{
    NSMutableData *serverData;
}

-(void)hitToActionWebService:(NSURL*)url;
{
    NSURLRequest *request=[[NSURLRequest alloc]initWithURL:url];
    
    NSURLConnection *connection=[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    [connection start];
    
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    serverData=[[NSMutableData alloc]init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [serverData appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSDictionary *responceData=[NSJSONSerialization JSONObjectWithData:serverData options:NSJSONReadingAllowFragments error:nil];
    
    NSLog(@"server is seccesse%@",responceData);
    
    [self.delegate222  success:responceData];
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{

    NSDictionary *dictData=[[NSDictionary alloc]initWithObjectsAndKeys:@"bindas Boy",@"usernName",nil];
    
    [self.delegate222 failure:dictData];
}


@end
