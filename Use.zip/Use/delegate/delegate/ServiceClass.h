//
//  ServiceClass.h
//  delegate
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol customProtocol;

@interface ServiceClass : NSObject

@property(weak,nonatomic)id<customProtocol>delegate222;

-(void)hitToActionWebService:(NSURL*)url;

@end


@protocol customProtocol <NSObject>

-(void)success:(NSDictionary*)success1;
-(void)failure:(NSDictionary*)failure2;


@end