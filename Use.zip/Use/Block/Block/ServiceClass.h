//
//  ServiceClass.h
//  Block
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceClass : NSObject

{
    void(^successDataLoad)(NSDictionary*);
    void(^failureDataLoad)(NSString*);
}

-(void) TapToHitSarvice:(NSURL*)url successBlock:(void(^)(NSDictionary*))success failureBolck:(void(^)(NSString*))failure;

@end
