//
//  ViewController.m
//  Block
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "ServiceClass.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSURL *url=[NSURL URLWithString:@"http;//sadsadsd.com"];
    ServiceClass *obj=[[ServiceClass alloc]init];
    [obj TapToHitSarvice:url
     
            successBlock:^(NSDictionary *ss)
    {
        NSLog(@"dff  %@",ss);
    }
   
            failureBolck:^(NSString *ss)
     {
         NSLog(@"show server error name ::%@",ss);
     }];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
