//
//  ServiceClass.m
//  Block
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ServiceClass.h"

@implementation ServiceClass
{
    NSMutableData *serverData;
}

-(void) TapToHitSarvice:(NSURL*)url successBlock:(void(^)(NSDictionary*))success failureBolck:(void(^)(NSString*))failure;
{
    successDataLoad=success;
    failureDataLoad=failure;
    NSURLRequest *request=[NSURLRequest requestWithURL:url];
    
    NSURLConnection *connection=[[NSURLConnection alloc]initWithRequest:request delegate:self];
    [connection start];
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    serverData=[[NSMutableData alloc]init];
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [serverData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSDictionary *response =[NSJSONSerialization JSONObjectWithData:serverData options:NSJSONReadingAllowFragments error:nil];
    
    NSLog(@"show server response %@",response);
    successDataLoad(response);
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSString *message=@"Fail To Load Page";
    failureDataLoad(message);
}


@end
