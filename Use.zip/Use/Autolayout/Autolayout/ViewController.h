//
//  ViewController.h
//  Autolayout
//
//  Created by ajay jha on 03/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

