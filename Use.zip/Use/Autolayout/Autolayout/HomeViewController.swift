//
//  HomeViewController.swift
//  Autolayout
//
//  Created by ajay jha on 05/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController
{
    let lblName = UILabel();
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
}
