//
//  ViewController.m
//  Autolayout
//
//  Created by ajay jha on 03/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(nonatomic, strong) UITableView *table;

@end
UITableView *table;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    table = [[UITableView alloc] initWithFrame:CGRectMake(10, 10, self.view.frame.size.width-200, 40)];
  //  table.delegate = self;
   // table.dataSource = self;
    table.layer.cornerRadius = 5;
    table.backgroundColor = [UIColor colorWithRed:0.239 green:0.239 blue:0.239 alpha:1];
    table.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    table.separatorColor = [UIColor grayColor];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
   
    table.frame = CGRectMake(0, 0, self.view.frame.size.width-200, 20);
    [UIView commitAnimations];
  //  [b.superview addSubview:self];

    
    //important link autolayout ::// https://www.youtube.com/watch?v=1XQorvd-VvI
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
