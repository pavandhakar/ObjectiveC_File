//
//  HomeViewController.m
//  notificationCenter
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "HomeViewController.h"
#import "ViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)callNotification:(id)sender
{
    
    NSMutableDictionary *allData=[[NSMutableDictionary alloc]init];
    
    [allData setObject:_Name.text forKey:@"name"];
    [allData setObject:_fatharName.text forKey:@"fname"];
    [allData setObject:_email.text forKey:@"email"];
    [allData setObject:_studentImage.image forKey:@"simage"];
    
    
    NSNotificationCenter *notify=[NSNotificationCenter defaultCenter];
    
    [notify postNotificationName: @"callingFromThis" object:allData];
    
}
-(IBAction)GoToView:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)saveImage:(id)sender
{
    UIImagePickerController *picker=[[UIImagePickerController alloc]init];
    [picker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
     picker.delegate=self;
    
    [self presentViewController:picker animated:YES completion:nil];
    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo
{
    
    self.studentImage.image=image;
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
