//
//  HomeViewController.h
//  notificationCenter
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController
-(IBAction)callNotification:(id)sender;

@property(strong,nonatomic)IBOutlet UITextField *Name;
@property(strong,nonatomic)IBOutlet UITextField *fatharName;
@property(strong,nonatomic)IBOutlet UITextField *email;
@property(strong,nonatomic)IBOutlet UIImageView *studentImage;


-(IBAction)saveImage:(id)sender;
-(IBAction)GoToView:(id)sender;

@end
