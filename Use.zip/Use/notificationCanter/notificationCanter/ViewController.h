//
//  ViewController.h
//  notificationCanter
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(strong,nonatomic)IBOutlet UILabel *lblName;
@property(strong,nonatomic)IBOutlet UILabel *lblFName;
@property(strong,nonatomic)IBOutlet UILabel *lblEmail;
@property(strong,nonatomic)IBOutlet UIImageView *imageShow;
-(IBAction)FillDetail:(id)sender;

@end

