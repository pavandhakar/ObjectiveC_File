//
//  ViewController.m
//  notificationCanter
//
//  Created by ajay jha on 02/11/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "HomeViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    NSNotificationCenter *def=[NSNotificationCenter defaultCenter];
    [def addObserver:self selector:@selector(ActionToView: ) name:@"callingFromThis" object:nil];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)ActionToView:(NSNotification *)responceData
{
    NSDictionary *data=responceData.object;
    NSString *name=[data objectForKey:@"name"];
    NSString *fName=[data objectForKey:@"fname"];
    NSString *email=[data objectForKey:@"email"];
    UIImage *sImage=[data objectForKey:@"simage"];
    self.lblName.text=name;
    self.lblFName.text=fName;
    self.lblEmail.text=email;
    self.imageShow.image=sImage;
    

}
-(IBAction)FillDetail:(id)sender
{
    HomeViewController *go=[self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    [self.navigationController pushViewController:go animated:YES];
 
}



@end
