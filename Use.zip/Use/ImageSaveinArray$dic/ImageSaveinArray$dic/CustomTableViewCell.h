//
//  CustomTableViewCell.h
//  ImageSaveinArray$dic
//
//  Created by ajay jha on 23/09/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *lblUserName;

@property(strong,nonatomic)IBOutlet UIImageView *showUserProfileImage;

@end
