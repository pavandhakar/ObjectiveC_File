//
//  ViewController.m
//  ImageSaveinArray$dic
//
//  Created by ajay jha on 19/09/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "HomeViewController.h"
@interface ViewController ()
{
    NSMutableArray *arrayData;
}

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
        // Do any additional setup after loading the view, typically from a nib.
    
    arrayData=[[NSMutableArray alloc]init];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)SaveData:(id)sender
{
    
    NSMutableDictionary *SaveVoluer=[[NSMutableDictionary alloc]init];
    
    [SaveVoluer setObject:_txtName.text forKey:@"SaveNme"];
    [SaveVoluer setObject:_txtAdd.text forKey:@"SaveAdd"];
    [SaveVoluer setObject:self.imageView.image forKey:@"image"];
    
    [arrayData addObject:SaveVoluer];
    
    
    
  //  [NSUserDefaults standardUserDefaults]
}
-(IBAction)SaveImage:(id)sender

{
    UIImagePickerController *ImagePicker=[[UIImagePickerController alloc]init];
    [ImagePicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    ImagePicker.delegate=self;
    [self presentViewController:ImagePicker animated:YES completion:nil];

}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo
{
    self.imageView.image=image;
    
    [self dismissViewControllerAnimated:YES completion:nil];

}

-(IBAction)GoHome:(id)sender
{
  
   NSDictionary *dict=[[NSUserDefaults standardUserDefaults]objectForKey:@"Alldat"];
    NSData *dtadt=[dict objectForKey:@"image"];
    UIImage *image=[UIImage imageWithData:dtadt];
    
    HomeViewController *GoHome=[self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    GoHome.arrayBack=arrayData;
    [self.navigationController pushViewController:GoHome animated:YES];
    
}

@end
