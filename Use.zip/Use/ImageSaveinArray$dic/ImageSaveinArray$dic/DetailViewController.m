//
//  DetailViewController.m
//  ImageSaveinArray$dic
//
//  Created by ajay jha on 22/09/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "DetailViewController.h"
#import "HomeViewController.h"
#import "ViewController.h"
@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *showDetailName=[self.showDataInDetailView objectForKey:@"SaveNme"];
    UIImage *showImage=[self.showDataInDetailView objectForKey:@"image"];
    
    self.lblShowUserNameDetail.text=showDetailName;
    self.showDetailImageDetail.image=showImage;
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
