//
//  ShowViewController.h
//  ImageSaveinArray$dic
//
//  Created by ajay jha on 22/09/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowViewController : UIViewController

@property(strong,nonatomic)NSDictionary *showDataInDetailView;

@property(strong,nonatomic)IBOutlet UILabel *lblShowUserNameDetail;

@property(strong,nonatomic)IBOutlet UIImageView *showDetailImageDetail;


@end
