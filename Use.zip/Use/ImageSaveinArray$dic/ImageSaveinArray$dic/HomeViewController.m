//
//  HomeViewController.m
//  ImageSaveinArray$dic
//
//  Created by ajay jha on 19/09/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "HomeViewController.h"
#import "ViewController.h"
#import "DetailViewController.h"
#import "ShowViewController.h"
#import "CustomTableViewCell.h"
@interface HomeViewController ()
{
}
@end

@implementation HomeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
   
  /*  NSMutableDictionary *BackData=[[NSUserDefaults standardUserDefaults]objectForKey:@"Alldat"];
    
    NSString *BName=[BackData objectForKey:@"SaveNme"];
    NSString *BAdd=[BackData objectForKey:@"SaveAdd"];
       NSLog(@"welcome To Home Page");
    self.txtName.text=BName;
    self.txtAdd.text=BAdd;
    */
   // NSDictionary *dict=[[NSUserDefaults standardUserDefaults]objectForKey:@"Alldat"];
  //NSArray *Data=[arrayBack objectAtIndex:<#(NSUInteger)#>]
  //  NSData *dtadt=[dict objectForKey:@"image"];
  //  self.image.image=[UIImage imageWithData:dtadt];
    // Do any additional setup after loading the view.
    
    
    
    
    self.showDataOnTableView.dataSource =self;
    self.showDataOnTableView.delegate =self;

    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
/*-(IBAction) Show:(id)sender

{

            NSString *showData=self.getNum.text;
       // self.txtName.text=showData;
       int a=[showData intValue];
    
        if (a<self.arrayBack.count)
        {
            
            NSDictionary *arrayBackData=[self.arrayBack objectAtIndex:a];
            
            NSString *backName=[arrayBackData objectForKey:@"SaveNme"];
            NSString *backAdd=[arrayBackData objectForKey:@"SaveAdd"];
            NSString *backImage=[arrayBackData objectForKey:@"image"];
            
            self.txtName.text=backName;
            self.txtAdd.text=backAdd;
            self.image.image=backImage;
        
        }
      if (a>self.arrayBack.count)
        {
            int b=self.arrayBack.count;
           NSString *d=@"wrong value";
            
            self.txtName.text=d;
            
            NSString *s=(@"please enter right value 0-");
            self.txtAdd.text=s;
            self.image.image=nil;
            
        }
        
    
}*/


//default table view example 22/09/2016
/*- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrayBack.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier=@"CellIdentifier";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell==nil)
    {
        cell =[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    NSDictionary *arrayBackData=[self.arrayBack objectAtIndex:indexPath.row];
    
    NSString *backName=[arrayBackData objectForKey:@"SaveNme"];
    UIImage *mageName=[arrayBackData objectForKey:@"image"];
    

    cell.textLabel.text =backName ;
    cell.imageView.image=mageName;
    
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   // [tableView deselectRowAtIndexPath:tableView animated:YES];
    
    NSDictionary *detailData=[self.arrayBack objectAtIndex:indexPath.row];
    
    ShowViewController *goDetail=[self.storyboard instantiateViewControllerWithIdentifier:@"ShowViewController"];
    
    goDetail.showDataInDetailView=detailData;
    
    [self.navigationController pushViewController:goDetail animated:YES];

}*/



//            **********      Custam table view example 23/09/2016      ***************


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arrayBack.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier=@"cellIdentifier";
    CustomTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:identifier];
   
    NSDictionary *arrayBackData=[self.arrayBack objectAtIndex:indexPath.row];
    
    NSString *backName=[arrayBackData objectForKey:@"SaveNme"];
    UIImage *mageName=[arrayBackData objectForKey:@"image"];
    
    cell.lblUserName.text =backName;
    cell.showUserProfileImage.image =mageName;
   
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
 
    
    NSDictionary *detailData=[self.arrayBack objectAtIndex:indexPath.row];
    
    ShowViewController *goDetail=[self.storyboard instantiateViewControllerWithIdentifier:@"ShowViewController"];
    
    goDetail.showDataInDetailView=detailData;
    
    [self.navigationController pushViewController:goDetail animated:YES];
    
}




@end
