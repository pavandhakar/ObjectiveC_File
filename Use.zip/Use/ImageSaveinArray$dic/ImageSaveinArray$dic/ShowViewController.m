//
//  ShowViewController.m
//  ImageSaveinArray$dic
//
//  Created by ajay jha on 22/09/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ShowViewController.h"
#import "HomeViewController.h"
#import "ViewController.h"
@interface ShowViewController ()

@end

@implementation ShowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSString *showDetailName=[self.showDataInDetailView objectForKey:@"SaveNme"];
    UIImage *showImage=[self.showDataInDetailView objectForKey:@"image"];
    
    self.lblShowUserNameDetail.text=showDetailName;
    self.showDetailImageDetail.image=showImage;

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
