//
//  HomeViewController.h
//  ImageSaveinArray$dic
//
//  Created by ajay jha on 19/09/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(strong,nonatomic)NSArray *arrayBack;

/*@property(strong,nonatomic)IBOutlet UITextField *getNum;

@property(strong,nonatomic)IBOutlet UILabel *txtName;

@property(strong,nonatomic)IBOutlet UILabel *txtAdd;

@property(strong,nonatomic)IBOutlet UIImageView *image;
-(IBAction) Show:(id)sender;*/


@property(strong,nonatomic)IBOutlet UITableView *showDataOnTableView;


@end
