//
//  ViewController.h
//  ImageSaveinArray$dic
//
//  Created by ajay jha on 19/09/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>



@property(strong,nonatomic)IBOutlet UITextField *txtName;
@property(strong,nonatomic)IBOutlet UITextField *txtAdd;
@property(strong,nonatomic)IBOutlet UIImageView *imageView;
@property(strong,nonatomic)IBOutlet NSData *nsData;


-(IBAction)SaveData:(id)sender;
-(IBAction)SaveImage:(id)sender;

-(IBAction)GoHome:(id)sender;

@end

