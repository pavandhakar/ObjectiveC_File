//
//  ViewController.m
//  SingletonClass
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "SingletonClass.h"
#import "HomeViewController.h"

@interface ViewController ()
{
    NSMutableArray *saveToArray;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    saveToArray =[[NSMutableArray alloc]init];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)saveData:(id)sender
{
    NSMutableDictionary *saveToDicti=[[NSMutableDictionary alloc]init];
    
    [saveToDicti setObject:_name.text forKey:@"Name"];
    [saveToDicti setObject:_mob.text forKey:@"Mobile"];
    [saveToDicti setObject:_email.text forKey:@"Email"];
    
    [saveToDicti setObject:_imageSave.image forKey:@"setImage"];
    
    [saveToArray addObject:saveToDicti];
    
    SingletonClass *obj=[SingletonClass custamSingleton];
    obj.shareByArray=saveToArray;
}
-(IBAction)saveImage:(id)sender
{
    UIImagePickerController *imagePacker=[[UIImagePickerController alloc]init];
    [imagePacker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary ];
    
    imagePacker.delegate=self;
    
    [self presentViewController:imagePacker animated:YES completion:nil];
    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo
{
    self.imageSave.image=image;
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)goShowDetail:(id)sender
{
    
    HomeViewController  *goHome=[self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
    
    [self.navigationController pushViewController:goHome animated:YES];
    
}





@end
