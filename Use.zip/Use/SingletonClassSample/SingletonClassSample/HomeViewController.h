//
//  HomeViewController.h
//  SingletonClassSample
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController


@property(strong,nonatomic)IBOutlet UILabel *nameBack;
@property(strong,nonatomic)IBOutlet UILabel *mobBack;
@property(strong,nonatomic)IBOutlet UILabel *emailBack;
@property(strong,nonatomic)IBOutlet UIImageView *imageSaveBack;


@end
