//
//  HomeViewController.m
//  SingletonClassSample
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "HomeViewController.h"
#import "SingletonClass.h"
#import "ViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    SingletonClass *objddd=[SingletonClass custamSingleton];
    NSArray *backData=objddd.shareByArray;
    NSDictionary *arrayToDict=[backData objectAtIndex:0];
    
    NSString *backName=[arrayToDict objectForKey:@"Name"];
    NSString *backMob=[arrayToDict objectForKey:@"Mobile"];
    NSString *backEmail=[arrayToDict objectForKey:@"Email"];

    UIImage *backImage=[arrayToDict objectForKey:@"setImage"];
    
    self.nameBack.text=backName;
    self.mobBack.text=backMob;
    self.emailBack.text=backEmail;
    
    self.imageSaveBack.image=backImage;

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
