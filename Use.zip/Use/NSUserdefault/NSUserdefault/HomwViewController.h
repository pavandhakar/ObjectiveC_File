//
//  HomwViewController.h
//  NSUserdefault
//
//  Created by ajay jha on 28/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomwViewController : UIViewController

@property(strong,nonatomic)IBOutlet UILabel *name;
@property(strong,nonatomic)IBOutlet UILabel *mobile;
@property(strong,nonatomic)IBOutlet UILabel *email;


@end
