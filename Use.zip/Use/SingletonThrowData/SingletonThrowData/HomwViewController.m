//
//  HomwViewController.m
//  SingletonThrowData
//
//  Created by ajay jha on 18/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "HomwViewController.h"
#import "SingletonClass.h"
#import "HomwViewController.h"
@interface HomwViewController ()

@end

@implementation HomwViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    SingletonClass *singData=[SingletonClass createSingleton];
    NSMutableArray *viewDAtaArr=singData.arraySingleton;
    
    NSMutableDictionary *backDic=[viewDAtaArr objectAtIndex:0];
    NSString *backName=[backDic objectForKey:@"Name"];
    NSString *backAdd=[backDic objectForKey:@"Add"];
    UIImage *backImage=[backDic objectForKey:@"Image"];
    self.showName.text=backName;
    self.showAddress.text=backAdd;
    self.showImage.image=backImage;
    

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
