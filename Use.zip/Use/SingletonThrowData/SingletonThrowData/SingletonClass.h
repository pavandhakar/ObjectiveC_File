//
//  SingletonClass.h
//  SingletonThrowData
//
//  Created by ajay jha on 18/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SingletonClass : NSObject

+(SingletonClass *) createSingleton;

@property(strong,nonatomic)NSMutableArray *arraySingleton;

@end
