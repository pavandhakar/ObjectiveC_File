//
//  SingletonClass.m
//  SingletonThrowData
//
//  Created by ajay jha on 18/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "SingletonClass.h"

@implementation SingletonClass

static SingletonClass *instance=nil;
+(SingletonClass *) createSingleton
{
    if (instance==nil) {
        instance =[[SingletonClass alloc]init];
        
    }
    return instance;
}

@end
