//
//  ViewController.m
//  SingletonThrowData
//
//  Created by ajay jha on 18/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import "ViewController.h"
#import "SingletonClass.h"
#import "HomwViewController.h"
@interface ViewController ()
{
    NSMutableArray *addmutarr;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    addmutarr =[[NSMutableArray alloc]init];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(IBAction)Save:(id)sender
{
 NSMutableDictionary *mutData=[[NSMutableDictionary alloc]init];
 [mutData setObject:_txtNAme.text forKey:@"Name"];
 [mutData setObject:_txtAdd.text forKey:@"Add"];
 [mutData setObject:_imgImage.image forKey:@"Image"];

 [addmutarr addObject:mutData];

 SingletonClass *storeData=[SingletonClass createSingleton];
  storeData.arraySingleton=addmutarr;

}
-(IBAction)SaveImage:(id)sender
{
    UIImagePickerController *imagePicker=[[UIImagePickerController alloc]init];
    [imagePicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    imagePicker.delegate=self;
    [self presentViewController:imagePicker animated:YES completion:nil];
    
    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo
{
    self.imgImage.image=image;
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)Show:(id)sender
{
    HomwViewController *showDataOnHome=[self.storyboard instantiateViewControllerWithIdentifier:@"HomwViewController"];
    [self.navigationController pushViewController:showDataOnHome animated:YES];
}



@end
