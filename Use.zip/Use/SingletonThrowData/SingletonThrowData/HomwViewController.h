//
//  HomwViewController.h
//  SingletonThrowData
//
//  Created by ajay jha on 18/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomwViewController : UIViewController

@property(strong,nonatomic)IBOutlet UILabel *showName;
@property(strong,nonatomic)IBOutlet UILabel *showAddress;
@property(strong,nonatomic)IBOutlet UIImageView *showImage;

@end
