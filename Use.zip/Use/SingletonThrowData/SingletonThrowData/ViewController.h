//
//  ViewController.h
//  SingletonThrowData
//
//  Created by ajay jha on 18/10/16.
//  Copyright © 2016 NY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property(strong,nonatomic)IBOutlet UITextField *txtNAme;
@property(strong,nonatomic)IBOutlet UITextField *txtAdd;
@property(strong,nonatomic)IBOutlet UIImageView *imgImage;
-(IBAction)Save:(id)sender;
-(IBAction)Show:(id)sender;
-(IBAction)SaveImage:(id)sender;

@end

